package com.example.debtapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class JsonTest extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_json_test);
        String json = getIntent().getStringExtra("json");
        TextView jsonTextView = findViewById(R.id.json_TextView);
        if (json != null){
            jsonTextView.setText(json);
        } else jsonTextView.setText("no data");

    }
}
